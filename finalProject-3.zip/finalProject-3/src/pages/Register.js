import React from 'react'

const Register = () => {
  return (
    <div>
      <h1>Sing up here</h1>
    </div>
  )
}

export default Register
