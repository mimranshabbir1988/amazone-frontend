import React from "react";

const AzadiOffer = () => {
  return (
    
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-12">
            <img src="./images/mainpage/banner1.jpg" width="100%" />
          </div>
        </div>
      </div>
    
  );
};

export default AzadiOffer;
