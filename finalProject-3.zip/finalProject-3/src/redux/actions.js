// actions

// import { ADD_TO_CART } from "./constant"

// const AddToCart = () =>{
//     return {
//         type: ADD_TO_CART,
//         data: 1
//     }
// }



// const AddToCart = () =>{
//     return {
//         type: "ADD_TO_CART",
//         data: 1
//     }
// }